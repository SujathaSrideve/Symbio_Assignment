'''
# This program store number from 1 to 100 in a file and then reads and print half of data from file to console.
Created on Sep 25, 2018
@author: sujathasrideve
'''
# Initializing total number of character to be zero in file. 
# File path is a location where the file will be created and stored. 
# It is taken as input from user.Try to use double slash like //Users//sujathasrideve//Writenum.txt

Total_Char = 0
File_Path = raw_input('Enter file path where the file must be stored  : ')

# A new file created to write all numbers between 1 to 100. 
# For loop iterates through all number and stores them in file separated by commas.

try:
    with open(File_Path, 'w+') as write_file:
        for i in range(1,101):
            write_file.write(str(i)+' ')
    
except IOError:
    print("Oops, Something went wrong with file operation ")

# Now the same file is opened in read mode to print half of the numbers to console
# Function 'rstrip' removes all spaces and helps to locate the middle of the file.

try:
    
    with open(File_Path, 'r') as read_file:
        for line in read_file:
            line.rstrip()    
            Total_Char += len(line)
        
        read_file.seek(0)   
        print(read_file.read(Total_Char/2))
        
except IOError: 
    print("Oops, Something went wrong with file operation ")    
 
    


